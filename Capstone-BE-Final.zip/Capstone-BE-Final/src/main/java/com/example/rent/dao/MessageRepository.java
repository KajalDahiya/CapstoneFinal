package com.example.rent.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.rent.entity.Message;

public interface MessageRepository extends JpaRepository<Message, Long> {
    // Define custom methods for message retrieval if needed
}
