package com.example.rent.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.rent.entity.Role;

@Repository
public interface RoleDao extends CrudRepository<Role, String> {

}
