import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../_model/product.model';
import { ProductService } from '../_services/product.service';

@Component({
  selector: 'app-product-view-details',
  templateUrl: './product-view-details.component.html',
  styleUrls: ['./product-view-details.component.css']
})
export class ProductViewDetailsComponent implements OnInit {

  selectedProductIndex = 0;

  // Initialize product as undefined
  product: Product | undefined;
  ratings: number[] = [4.2, 3.8, 4.5, 3.9, 4.7]; // Add your different ratings here
  reviewCounts: number[] = [80, 120, 90, 150, 200]; // Add your different review counts here


  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private productService: ProductService
  ) { }

  ngOnInit(): void {
    this.product = this.activatedRoute.snapshot.data['product'];
    console.log(this.product);
  }

  addToCart(productId: any) {
    this.productService.addToCart(productId).subscribe(
      (response) => {
        console.log(response);
      }, 
      (error) => {
        console.log(error);
      }
    );
  }

  changeIndex(index: any) {
    this.selectedProductIndex = index;
  }

  buyProduct(productId: any) {
    this.router.navigate(['/buyProduct', {
      isSingleProductCheckout: true, id: productId
    }]);
  }
  
  getRandomRating(): number {
    const randomIndex = Math.floor(Math.random() * this.ratings.length);
    return this.ratings[randomIndex];
  }

  getRandomReviewCount(): number {
    const randomIndex = Math.floor(Math.random() * this.reviewCounts.length);
    return this.reviewCounts[randomIndex];
  }
}
