import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutdevelopers',
  templateUrl: './aboutdevelopers.component.html',
  styleUrls: ['./aboutdevelopers.component.css']
})
export class AboutdevelopersComponent {

}
