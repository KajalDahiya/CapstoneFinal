import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { interval, Subject } from 'rxjs';
import { switchMap, takeUntil } from 'rxjs/operators';
import { MessageService } from '../_services/message.service';
import { Message } from '../_model/message.model';

@Component({
  selector: 'app-user-chat',
  templateUrl: './user-chat.component.html',
  styleUrls: ['./user-chat.component.css']
})
export class UserChatComponent implements OnInit, OnDestroy {
  messages: Message[] = [];
  messageForm!: FormGroup;
  displayMessages: Message[] = [];
  readonly initialDisplayCount = 10; // Initial number of messages to display
  @ViewChild('scrollBottom') private scrollBottom!: ElementRef;
  private destroy$ = new Subject<void>(); // Subject to unsubscribe from observables

  constructor(
    private formBuilder: FormBuilder,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {
    this.loadChatHistory();
    this.initForm();
    this.startPolling();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  initForm(): void {
    this.messageForm = this.formBuilder.group({
      newMessage: ['', Validators.required]
    });
  }

  loadChatHistory() {
    this.messageService.getAllMessages().subscribe((data) => {
      this.messages = data.reverse(); // Reverse the array to show recent messages first
      this.displayMessages = this.messages.slice(0, this.initialDisplayCount); // Load initial messages to display
    });
  }

  sendMessage(): void {
    if (this.messageForm.valid) {
      const newChatMessage: Message = {
        sender: 'User',
        receiver: 'Admin',
        message: this.messageForm.value.newMessage
      };

      this.messageService.sendMessage(newChatMessage).subscribe(
        (data) => {
          this.messages.unshift(data); // Add the new message to the beginning of the array
          this.displayMessages = this.messages.slice(0, this.initialDisplayCount); // Update displayed messages
          this.messageForm.reset(); // Reset the form after sending
        },
        (error) => {
          console.error('Error sending message:', error);
          // Handle error accordingly
        }
      );
    }
  }

  startPolling(): void {
    interval(5000) // Polling interval in milliseconds (e.g., fetch every 5 seconds)
      .pipe(
        takeUntil(this.destroy$),
        switchMap(() => this.messageService.getAllMessages())
      )
      .subscribe((data) => {
        this.messages = data.reverse();
        this.displayMessages = this.messages.slice(0, this.initialDisplayCount);
      });
  }

  onScroll(event: Event) {
    const el = event.target as HTMLElement;
    const atBottom = el.scrollHeight - el.scrollTop === el.clientHeight;
    if (atBottom) {
      // User scrolled to bottom
      this.displayMessages = this.messages.slice(0, this.initialDisplayCount);
    }
  }

  scrollToBottom(): void {
    try {
      this.scrollBottom.nativeElement.scrollTop = this.scrollBottom.nativeElement.scrollHeight;
    } catch (err) {
      console.error(err);
    }
  }
}
