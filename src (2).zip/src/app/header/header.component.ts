// header.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserAuthService } from '../_services/user-auth.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  
  constructor(
    private userAuthService: UserAuthService,
    private router: Router,
    public userService: UserService,
    
  ) {}
  

  ngOnInit(): void {
    
  }
  isLoggedIn(): boolean {
    return this.userAuthService.isLoggedIn();
  }

  logout(): void {
    this.userAuthService.clear();
    this.router.navigate(['/']);
  }

  isAdmin(): boolean {
    return this.userAuthService.isAdmin();
  }

  isUser(): boolean {
    return this.userAuthService.isUser();
  }

  isLoginPage(): boolean {
    return this.router.url.includes('/login');
  }

  isRegisterPage(): boolean {
    return this.router.url.includes('/register');
  }

  isAdminPage(): boolean {
    return this.router.url.includes('/admin');
  }

  isAddNewProduct(): boolean {
    return this.router.url.includes('/addNewProduct');
  }
  
}
