import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from '../_model/product.model';
import { OrderDetails } from '../_model/order-details.model';
import { Observable } from 'rxjs';
import { MyOrderDetails } from '../_model/order.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'http://localhost:9091';

  constructor(private httpClient: HttpClient) { }
  addProduct(product: Product): Observable<Product> {
    const headers = new HttpHeaders();
    headers.set('Content-Type', 'multipart/form-data');
    
    const options = { headers: headers };
    
    const formData = new FormData();
    formData.append('product', new Blob([JSON.stringify(product)], { type: 'application/json' }));
    
    for (let i = 0; i < product.productImages.length; i++) {
    formData.append('imageFile', product.productImages[i].file, product.productImages[i].file.name);
    }
    
    return this.httpClient.post<Product>(`${this.apiUrl}/addNewProduct`, formData, options);
    }

  public getAllProducts(pageNumber: string | number | undefined, searchKeyword:string=""){
    return this.httpClient.get<Product[]>("http://localhost:9091/getAllProducts?pageNumber="+pageNumber+"&searchKey="+searchKeyword);
  }

  public getProductDetailsById(productId: string){
    return this.httpClient.get<Product>("http://localhost:9091/getProductDetailsById/"+productId);
  }
  public deleteProduct(productId:number){
    return this.httpClient.delete("http://localhost:9091/deleteProductDetails/"+productId);
  }

   public getProductDetails(isSingleProductCheckout: string | null, productId: string | null){
    return this.httpClient.get<Product[]>("http://localhost:9091/getProductDetails/"+isSingleProductCheckout+"/"+productId)
}

public placeOrder(orderDetails: OrderDetails, isCartCheckout: string | undefined) {
  return this.httpClient.post("http://localhost:9091/placeOrder/"+isCartCheckout, orderDetails);
}

public addToCart(productId: string){
  return this.httpClient.get("http://localhost:9091/addToCart/"+productId);
}

public getCartDetails() {
  return this.httpClient.get("http://localhost:9091/getCartDetails");
}

public deleteCartItem(cartId: string) {
  return this.httpClient.delete("http://localhost:9091/deleteCartItem/"+cartId);
}

public getMyOrders(): Observable<MyOrderDetails[]> {
  return this.httpClient.get<MyOrderDetails[]>("http://localhost:9091/getOrderDetails");
}

public getAllOrderDetailsForAdmin(status: string): Observable<MyOrderDetails[]> {
  return this.httpClient.get<MyOrderDetails[]>("http://localhost:9091/getAllOrderDetails/"+status);
}

public markAsDelivered(orderId: string) {
  return this.httpClient.get("http://localhost:9091/markOrderAsDelivered/"+orderId)
}

}






