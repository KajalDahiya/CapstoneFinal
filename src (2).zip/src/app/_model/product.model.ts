import { FileHandle } from "./file-handle.model";

export interface Product{
    productId: number;

    // subscribe(arg0: (response: Product) => void, arg1: (error: import("@angular/common/http").HttpErrorResponse) => void): Product;
    productName: string,
    productLocation:string,
    productDescription: string,
    productDiscountedPrice: number,
    productPrice: number,
    productImages: FileHandle[]
}