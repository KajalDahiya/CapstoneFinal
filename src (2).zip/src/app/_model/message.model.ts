// message.model.ts
export interface Message {
    id?: number;
    sender: string;
    receiver: string;
    message: string;
    timestamp?: string; // Adjust the timestamp format as per your backend
  }
  